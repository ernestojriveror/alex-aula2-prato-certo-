# Prato Certo – MVP

## Problema
Adultos que querem melhorar a alimentação têm dificuldade para saber quantas calorias e nutrientes precisam e como distribuí-los nas refeições, porque dependem de informações genéricas ou de dietas copiadas. Isso gera planos inadequados, desistência e, em alguns casos, riscos à saúde.

## Escopo da versão 1
- Somente adultos de 19 a 59 anos.
- Português do Brasil, com alimentos comuns no país.
- Dados guardados apenas no dispositivo.
- O plano dura até alcançar o peso meta, com menus para todo o período e pesagem de revisão a cada 7 dias.
- Protótipo em HTML para validar o fluxo; depois, aplicativo em Flutter (Android e desktop).

## Persona
Mariana Souza, 32 anos, Joinville, SC. Analista de marketing, treina 3 vezes por semana. Quer perder alguns quilos, mas não sabe quanto deve comer.

## Histórias de usuário
1. Informar meus dados e meu objetivo, para receber metas adequadas.
2. Ver IMC, calorias, macros e água, para entender minhas necessidades.
3. Receber um cardápio em 4 refeições, para saber o que comer.
4. Ser avisada quando o objetivo não for coerente com o perfil.
5. Ser orientada a procurar um profissional em caso de gravidez, doença ou transtorno alimentar.
6. Ter meus dados salvos no aparelho.
7. Informar meu peso meta e saber quanto tempo o plano deve durar.
8. Ver o cardápio de cada dia até alcançar a meta.
9. Registrar meu peso toda semana e ter as metas recalculadas.
10. Trocar o cardápio, para ter variedade.

## Hipóteses
- H1: as pessoas se baseiam em dietas genéricas. Validar com 3 a 5 entrevistas.
- H2: metas claras em uma tela aumentam a confiança. Validar com teste do protótipo.
- H3: um cardápio-base simples é mais útil que um plano detalhado.
- H4: os usuários aceitam uma triagem de segurança no início.
- H5: alertas claros reduzem objetivos inadequados. Validar com perfis de risco simulados.

## Priorização (MoSCoW)
- **Must:** triagem de segurança, perfil, peso meta e duração estimada, cálculo de IMC/calorias/macros/água, cardápio em 4 refeições para todo o período, revisão semanal com recálculo, alertas, guardar perfil.
- **Should:** trocar cardápio, limites do dia (açúcar, sal, frutas e legumes).
- **Could:** registro de peso, lista de compras, lembretes.
- **Won't:** menores de 19 e maiores de 59, gestantes e doentes, código de barras e foto, contas e nuvem, chat com IA.

## Regras do motor de cálculo
| Regra | Cálculo | Base |
|---|---|---|
| Metabolismo basal | Mifflin-St Jeor: 10×peso + 6,25×altura − 5×idade + 5 (H) ou − 161 (M) | Equação publicada |
| Gasto diário | Basal × 1,2 / 1,55 / 1,75 | Critério do protótipo |
| Objetivo | Perder −400 kcal; ganhar +300 kcal | Critério do protótipo |
| Piso | 1.200 kcal (M) e 1.500 kcal (H) | Critério do protótipo |
| Proteínas | 1,0 / 1,3 / 1,6 g/kg, máx. 30% das calorias | Critério do protótipo |
| Gorduras | 25% das calorias | OMS (menos de 30%) |
| Ritmo | Déficit/superávit diário × 7 ÷ 7.700 kcal por kg (≈ 0,36 kg/semana ao perder; 0,27 ao ganhar) | Aproximação do protótipo |
| Duração | \|meta − peso\| ÷ ritmo, em semanas; manutenção: ciclo de 4 semanas | Cálculo |
| Meta válida | Meta na direção do objetivo e com IMC ≥ 18,5; acima de 24,9 gera o plano com aviso e mostra a faixa de peso ideal | Critério do protótipo |
| Revisão | Pesagem a cada 7 dias, com recálculo; ao atingir a meta, passa para manutenção | Critério do protótipo |
| Água | 35 mL/kg (+500 mL se ativo) | Estimativa do protótipo |
| Açúcar livre | Até 10% das calorias | OMS |
| Sal | Menos de 5 g/dia | OMS |
| Frutas e legumes | Pelo menos 400 g/dia, sem raízes como batata e mandioca | OMS |

As regras do protótipo precisam ser validadas por um nutricionista antes de qualquer uso real.

## Segurança
O app não gera plano em caso de gravidez/amamentação, condições médicas, transtorno alimentar, idade fora de 19–59 anos ou IMC abaixo de 18,5 com objetivo de perder peso. É orientação geral e não substitui nutricionista ou médico.
