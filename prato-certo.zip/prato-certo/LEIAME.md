# Prato Certo – Pacote do MVP

- documento-mvp.pdf: documento do MVP com as capturas das telas.
- documentacao-mvp.md: mesma definição em texto simples.
- prototipo-telas.html: protótipo funcional (perfil, resultados e dieta). Abra no navegador com um clique duplo.

Observação: as regras de cálculo do protótipo devem ser validadas por um nutricionista antes de qualquer uso real.
